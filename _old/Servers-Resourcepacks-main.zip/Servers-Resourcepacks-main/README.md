# Servers-Resourcepacks
Contains the HoGS Minecraft server resource packs!
