# Servers-Datapacks
Contains the HoGS Minecraft server data packs!
